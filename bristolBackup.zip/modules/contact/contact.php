<?php
# Send to your email address
$sendTo = "ventas@hotelbristol.com.ar";
# Subject line
$subject = "Formulario Web Hotel Bristol";
# Send from address
$sendFrom = "FROM: info@hotelbristol.com.ar";
# Body 
$body = "A user has left the following information \n \n Name: " . stripslashes($_POST["yourName_txt"]) . " \n Phone #: " . stripslashes($_POST["phone_txt"]) . "\n Email Address: " . stripslashes($_POST["email_txt"]) . "\n Comments: " . stripslashes($_POST["comments_txt"]);
# Send mail
mail($sendTo, $subject, $body, $sendFrom);
?>